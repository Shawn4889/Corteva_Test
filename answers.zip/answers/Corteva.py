#Author: Xiaoxuan Li
import pandas as pd
import os


dir = r"C:\Users\Shawn\Desktop\Corteva\DataSciTest.tar\DataSciTest\DataSciTest/"
dir_wx_data = dir + "wx_data/"
dir_yld_data = dir + "yld_data/"
dir_p1_output_txt = dir + "answers/MissingPrcpData.out"
dir_p2_output_txt = dir + "answers/YearlyAverages.out"

#Q1
def Q1():
    wx_data_files = os.listdir(dir_wx_data)
    p1_index = 0
    with open(dir_p1_output_txt, 'w') as output:
        for wx_data_file in wx_data_files:
            p1_index = 0
            wx_data_file_full = dir_wx_data + wx_data_file
            df_wx_data = pd.read_csv(wx_data_file_full, sep="\t", names=["Date", "Max", "Min", "Precipitation"])
            for index, row in df_wx_data.iterrows():
                if row["Max"] != -9999 and row["Min"] != -9999 and row["Precipitation"] == -9999:
                    p1_index += 1

            print(wx_data_file + "  " + str(p1_index))
            output.write(wx_data_file + "  " + str(p1_index) + '\n')

#Q2
def Q2():
    wx_data_files = os.listdir(dir_wx_data)
    p2_index = []
    df_p2_df = pd.DataFrame(p2_index)
    for wx_data_file in wx_data_files:
        print(wx_data_file)
        p1_index = 0
        wx_data_file_full = dir_wx_data + wx_data_file
        df = pd.read_csv(wx_data_file_full, sep="\t", names=["Date", "Max", "Min", "Precipitation"])
        df = df[df.Max != -9999]
        df = df[df.Min != -9999]
        df = df[df.Precipitation != -9999]
        df['Date'] = df['Date'].astype(str)
        df["Year"] = df.Date.str.extract(r'(\d{1,4})').squeeze().str.zfill(4)
        df_Avg_Max = df.groupby('Year')['Max'].mean()/10
        df_Avg_Min = df.groupby('Year')['Min'].mean()/10
        df_Sum_Precipitation = df.groupby('Year')['Precipitation'].sum()/10
        df_Avg_Max = df_Avg_Max.round(decimals=2)
        df_Avg_Min = df_Avg_Min.round(decimals=2)
        df_Sum_Precipitation = df_Sum_Precipitation.round(decimals=2)
        df_combine = pd.concat([df_Avg_Max,df_Avg_Min,df_Sum_Precipitation],axis=1)
        df_combine.reset_index(inplace=True)
        df_combine["Filename"] = wx_data_file
        df_combine = df_combine[["Filename","Year","Max","Min","Precipitation"]]
        df_p2_df = pd.concat([df_p2_df,df_combine])
    df_p2_df.to_csv(dir_p2_output_txt,index=False)
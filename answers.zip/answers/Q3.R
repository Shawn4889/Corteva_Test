#Author: Xiaoxuan Li
library(corrplot)
library(tidyverse)
library(psych)
library(xlsx)
library(car)
library(MASS)
library(rsq)
library(dplyr)
library(rlist)
library(data.table)
library(lemon)
library(lmtest)
library(reshape2)
library(ggpubr)
library(ggplot2)
library(mltools)
library(tidyr)
library(stats)
library(tools) 
library(grid)
library(readxl)
library(Hmisc)
windowsFonts(A = windowsFont("Times New Roman"))
# ------------------------------------------------------------------------------------------------ #
#Q3

file <- "C:\\Users\\Shawn\\Desktop\\Corteva\\DataSciTest.tar\\DataSciTest\\DataSciTest\\answers\\YearlyAverages.out"
output <- "C:\\Users\\Shawn\\Desktop\\Corteva\\DataSciTest.tar\\DataSciTest\\DataSciTest\\answers\\YearHistogram.out"
Data <- read.csv(file, header = TRUE, sep = ",")
Files <- unique(Data$Filename)
Years <- unique(Data$Year)
list_max = 0
list_min = 0
list_prep = 0

for (file in Files){
  Data_file <- Data[Data$Filename ==file,]
  Year_sel <- Data_file[Data_file$Max == max(Data_file$Max), "Year"]
  print(Year_sel)
  list_max <- append(list_max,Year_sel)
  
  Year_sel <- Data_file[Data_file$Min == max(Data_file$Min), "Year"]
  print(Year_sel)
  list_min <- append(list_min,Year_sel)
  
  Year_sel <- Data_file[Data_file$Precipitation == max(Data_file$Precipitation), "Year"]
  print(Year_sel)
  list_prep <- append(list_prep,Year_sel)
}
list_max <- list_max[list_max != 0]
list_min <- list_min[list_min != 0]
list_prep <- list_prep[list_prep != 0]

df_max <- data.frame(list_max)
df_min <- data.frame(list_min)
df_prep <- data.frame(list_prep)


df_combine <- data.frame(cbind(table(df_max),table(df_min),table(df_prep)))
df_combine<- df_combine %>% 
  rename(
    Max = X1,
    Min = X2,
    Precipitation = X3
  )
df_combine$Year <- rownames(df_combine)
df_combine <- df_combine[, c(4, 1, 2, 3)]
write.table(df_combine,output, sep = " ")

df_max$Group <- "Max"
df_min$Group <- "Min"
df_prep$Group <- "Precipitation"
df_max<- df_max %>% 
  rename(
    Value = list_max
  )
df_min<- df_min %>% 
  rename(
    Value = list_min
  )
df_prep<- df_prep %>% 
  rename(
    Value = list_prep
  )
data <- rbind(df_max,df_min,df_prep)

data %>%
  ggplot( aes(x=Value, fill=Group)) +
  theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  labs(x="Year")+
  scale_x_continuous(limits = c(1985,2014),breaks = seq(1985,2014,1))+
  theme(text=element_text(family="A"))+
  theme(legend.title = element_blank())+
  theme(text=element_text(size=25),axis.text=element_text(size=25))

output <- "C:\\Users\\Shawn\\Desktop\\Corteva\\DataSciTest.tar\\DataSciTest\\DataSciTest\\answers\\YearHistogram.jpg"
ggsave(output,height=12, width=36, dpi=600)

# ------------------------------------------------------------------------------------------------ #
#Q4
file <- "C:\\Users\\Shawn\\Desktop\\Corteva\\DataSciTest.tar\\DataSciTest\\DataSciTest\\answers\\YearlyAverages.out"
fiel_yld <-"C:\\Users\\Shawn\\Desktop\\Corteva\\DataSciTest.tar\\DataSciTest\\DataSciTest\\yld_data\\US_corn_grain_yield.txt"
output <- "C:\\Users\\Shawn\\Desktop\\Corteva\\DataSciTest.tar\\DataSciTest\\DataSciTest\\answers\\Correlations.out"
Data <- read.csv(file, header = TRUE, sep = ",")
Data_yld <- read.csv(fiel_yld, sep = "\t", header=FALSE)
colnames(Data_yld)<- c("Year","Yield")
Files <- unique(Data$Filename)
list_append = 0
df_append <- data.frame(list_append)
i <- 0
for (file in Files){
  print(file)
  Data_file <- Data[Data$Filename ==file,]
  df = merge(x = Data_file, y = Data_yld, by = "Year")
  c1 <- round(cor(df$Max, df$Yield, method = c("pearson")),2)
  c2 <- round(cor(df$Min, df$Yield, method = c("pearson")),2)
  c3 <- round(cor(df$Precipitation, df$Yield, method = c("pearson")),2)
  df_append[i,1] = c1
  df_append[i,2] = c2
  df_append[i,3] = c3
  df_append[i,4] = basename(file)
  i = i+1
}


df_append<- df_append %>% 
  rename(
    
    Max = list_append,
    Min = V2,
    Precipitation = V3,
    Filename = V4
  )

df_append <- df_append[, c(4, 1, 2, 3)]
write.table(df_append,output, sep = " ", row.names = FALSE)

